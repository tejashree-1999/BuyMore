/**
 * Admin: media picker for the favourites slider images.
 */
( function ( $ ) {
	'use strict';
	var frame;

	$( '#bmd-gallery-btn' ).on( 'click', function ( e ) {
		e.preventDefault();
		if ( ! frame ) {
			frame = wp.media( {
				title: 'Select slider images',
				button: { text: 'Use these images' },
				multiple: 'add',
				library: { type: 'image' }
			} );
			frame.on( 'select', function () {
				var ids = [];
				var $preview = $( '#bmd-gallery-preview' ).empty();
				frame.state().get( 'selection' ).each( function ( att ) {
					var a = att.toJSON();
					ids.push( a.id );
					var src = ( a.sizes && a.sizes.thumbnail ) ? a.sizes.thumbnail.url : a.url;
					$preview.append( $( '<img>', { src: src, width: 60, height: 60 } ) );
				} );
				$( '#bmd_gallery' ).val( ids.join( ',' ) );
			} );
			frame.on( 'open', function () {
				var ids = ( $( '#bmd_gallery' ).val() || '' ).split( ',' ).filter( Boolean );
				var sel = frame.state().get( 'selection' );
				ids.forEach( function ( id ) { sel.add( wp.media.attachment( id ) ); } );
			} );
		}
		frame.open();
	} );
} )( jQuery );

/* Picking a background colour automatically unticks "No background colour". */
jQuery( function ( $ ) {
	$( '#bmd_bg_color' ).on( 'input change', function () {
		$( 'input[name="bmd_bg_color_clear"]' ).prop( 'checked', false );
	} );
} );
