/**
 * BuyMore Dashboard - front-end behaviour (vanilla JS, no dependencies).
 * Features: mobile drawer, gender tabs (REST), wishlist hearts,
 * favourites slider, card search, Dashboard/Website switch.
 */
( function () {
	'use strict';

	function init( app ) {
		var grid = app.querySelector( '[data-bmd-grid]' );
		var tabsWrap = app.querySelector( '[data-bmd-tabs]' );
		var tools = app.querySelector( '.bmd-tools' );
		var search = app.querySelector( '[data-bmd-search]' );
		var reqId = 0;

		/* Mobile / tablet drawer */
		app.addEventListener( 'click', function ( e ) {
			if ( e.target.closest( '[data-bmd-nav-toggle]' ) ) {
				app.classList.toggle( 'is-nav-open' );
			}
		} );
		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) {
				app.classList.remove( 'is-nav-open' );
			}
		} );

		/* Dashboard / Website switch */
		var sw = app.querySelector( '.bmd-switch' );
		if ( sw ) {
			sw.addEventListener( 'click', function ( e ) {
				var btn = e.target.closest( 'button' );
				if ( ! btn ) { return; }
				sw.querySelectorAll( 'button' ).forEach( function ( b ) {
					var on = b === btn;
					b.classList.toggle( 'is-active', on );
					b.setAttribute( 'aria-selected', on ? 'true' : 'false' );
				} );
			} );
		}

		/* Event delegation so it keeps working after the grid is replaced */
		grid.addEventListener( 'click', function ( e ) {
			var heart = e.target.closest( '.bmd-heart' );
			if ( heart ) {
				var on = heart.classList.toggle( 'is-active' );
				heart.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
				return;
			}
			var arrow = e.target.closest( '[data-bmd-slide]' );
			if ( arrow ) {
				var track = arrow.closest( '.bmd-card' ).querySelector( '.bmd-fav__track' );
				var slide = track.querySelector( '.bmd-fav__slide' );
				var step = slide ? slide.getBoundingClientRect().width + 6 : track.clientWidth / 2;
				track.scrollBy( { left: step * parseInt( arrow.getAttribute( 'data-bmd-slide' ), 10 ), behavior: 'smooth' } );
			}
		} );

		/* Gender tabs: fetch rendered cards from the REST API */
		if ( tabsWrap && window.BMD ) {
			tabsWrap.addEventListener( 'click', function ( e ) {
				var tab = e.target.closest( '.bmd-tab' );
				if ( ! tab || tab.classList.contains( 'is-active' ) ) { return; }

				tabsWrap.querySelectorAll( '.bmd-tab' ).forEach( function ( t ) {
					var on = t === tab;
					t.classList.toggle( 'is-active', on );
					t.setAttribute( 'aria-selected', on ? 'true' : 'false' );
				} );

				var id = ++reqId;
				var url = new URL( window.BMD.restUrl, window.location.href );
				url.searchParams.set( 'gender', tab.getAttribute( 'data-gender' ) );

				grid.classList.add( 'is-loading' );
				fetch( url.toString(), { credentials: 'same-origin' } )
					.then( function ( r ) { return r.json(); } )
					.then( function ( data ) {
						if ( id !== reqId ) { return; } // ignore stale responses
						grid.innerHTML = data.html || '';
						if ( search && search.value ) { applySearch( search.value ); }
					} )
					.catch( function () {
						grid.innerHTML = '<p class="bmd-empty">Could not load cards. Please try again.</p>';
					} )
					.finally( function () { grid.classList.remove( 'is-loading' ); } );
			} );
		}

		/* Search (client-side title filter) */
		function applySearch( term ) {
			term = term.trim().toLowerCase();
			grid.querySelectorAll( '.bmd-card' ).forEach( function ( card ) {
				var title = card.getAttribute( 'data-title' ) || '';
				card.classList.toggle( 'is-hidden', term !== '' && title.indexOf( term ) === -1 );
			} );
		}
		var toggle = app.querySelector( '[data-bmd-search-toggle]' );
		if ( toggle && tools && search ) {
			toggle.addEventListener( 'click', function () {
				var open = tools.classList.toggle( 'is-searching' );
				if ( open ) {
					search.focus();
				} else {
					search.value = '';
					applySearch( '' );
				}
			} );
			search.addEventListener( 'input', function () { applySearch( search.value ); } );
		}
	}

	document.querySelectorAll( '[data-bmd-app]' ).forEach( init );
} )();
