<?php
/**
 * Runs when the plugin is deleted from the Plugins screen.
 * Removes settings only; cards (posts) are kept so content is never lost.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_option( 'bmd_settings' );
delete_option( 'bmd_seeded' );
delete_option( 'bmd_version' );
