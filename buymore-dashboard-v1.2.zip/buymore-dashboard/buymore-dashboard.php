<?php
/**
 * Plugin Name:       BuyMore Dashboard
 * Plugin URI:        https://example.com/buymore-dashboard
 * Description:       Responsive "BuyMore" fashion dashboard page built without page builders. Cards, filters and sidebar are fully editable from the WordPress admin. Use the [buymore_dashboard] shortcode.
 * Version:           1.2.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Your Name
 * License:           GPL-2.0-or-later
 * Text Domain:       buymore-dashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BMD_VERSION', '1.2.0' );
define( 'BMD_FILE', __FILE__ );
define( 'BMD_PATH', plugin_dir_path( __FILE__ ) );
define( 'BMD_URL', plugin_dir_url( __FILE__ ) );

require_once BMD_PATH . 'includes/class-icons.php';
require_once BMD_PATH . 'includes/class-post-types.php';
require_once BMD_PATH . 'includes/class-meta-boxes.php';
require_once BMD_PATH . 'includes/class-settings.php';
require_once BMD_PATH . 'includes/class-renderer.php';
require_once BMD_PATH . 'includes/class-shortcode.php';
require_once BMD_PATH . 'includes/class-rest.php';
require_once BMD_PATH . 'includes/class-seeder.php';

/**
 * Boot all components.
 */
function bmd_boot() {
	new BMD_Post_Types();
	new BMD_Meta_Boxes();
	new BMD_Settings();
	new BMD_Shortcode();
	new BMD_Rest();
}
add_action( 'plugins_loaded', 'bmd_boot' );

/**
 * Card images are served at 800px wide (height auto) so they stay sharp
 * when they fill a card. New uploads get this size automatically.
 */
function bmd_image_sizes() {
	add_image_size( 'bmd_card', 800, 9999, false );
}
add_action( 'after_setup_theme', 'bmd_image_sizes' );

/**
 * Activation: register CPT/taxonomy, seed demo content, flush rewrites.
 */
function bmd_activate() {
	BMD_Post_Types::register();
	BMD_Seeder::seed();
	BMD_Seeder::dedupe();
	update_option( 'bmd_version', BMD_VERSION );
	flush_rewrite_rules();
}
register_activation_hook( BMD_FILE, 'bmd_activate' );

/**
 * One-time housekeeping when the plugin version changes (also covers
 * "replace with uploaded zip", which does not always fire the activation hook):
 * trims accidental duplicate demo cards.
 */
function bmd_maybe_upgrade() {
	if ( get_option( 'bmd_version' ) !== BMD_VERSION ) {
		BMD_Seeder::dedupe();
		update_option( 'bmd_version', BMD_VERSION );
	}
}
add_action( 'admin_init', 'bmd_maybe_upgrade' );

function bmd_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( BMD_FILE, 'bmd_deactivate' );
