# BuyMore Dashboard (WordPress plugin)

A fully responsive fashion-dashboard page, hand-coded (PHP, HTML, CSS, vanilla JS). No Elementor or page builders. Every card, menu and label is editable from the WordPress admin.

## Install
1. Zip the `buymore-dashboard` folder (or use the provided zip).
2. WordPress admin > Plugins > Add New > Upload Plugin > select the zip > Activate.
3. Activation creates 7 demo cards and the Men / Women / Unisex terms.
4. Create a Page, add the shortcode `[buymore_dashboard]` and publish.

Shortcode options: `[buymore_dashboard limit="20" fullwidth="yes"]`
(`fullwidth="yes"` breaks out of the theme content column; use `no` to stay inside it.)

## Manage content
| Where | What |
|---|---|
| **BuyMore > All Cards / Add New** | Each grid card is a post. Title, Featured Image, Order (Page Attributes) and the *Card details* box (type, size, subtitle, button, price, colours, background, slider images). |
| **BuyMore > Genders** | Terms that drive the All / Men / Women tabs. Add a term and a new tab appears. "Unisex" cards show under every tab. |
| **BuyMore > Dashboard Settings** | Logo, orders number, cart, user, section title, sidebar menu, quick actions, last orders. |

## Architecture
```
buymore-dashboard.php        bootstrap, constants, activation hooks
uninstall.php                removes settings on delete
includes/
  class-post-types.php       CPT bmd_card + taxonomy bmd_gender + admin columns
  class-meta-boxes.php       native meta box (nonce, capability, sanitisation)
  class-settings.php         Settings API page + helpers
  class-renderer.php         WP_Query, card data, template loader
  class-shortcode.php        [buymore_dashboard] + conditional asset loading
  class-rest.php             GET /wp-json/buymore/v1/cards?gender=men
  class-seeder.php           demo content on activation
  class-icons.php            inline SVG icons
templates/                   dashboard.php + parts/ (sidebar, one file per card type)
assets/css|js|img            styles, front-end JS, admin media picker, placeholders
```

## How it works
1. The shortcode loads `templates/dashboard.php`.
2. `BMD_Renderer::cards_html()` runs a `WP_Query` ordered by `menu_order` and renders `parts/card-{type}.php` per card.
3. The tabs call the REST endpoint, which returns the same rendered HTML, and the grid is swapped without a page reload.
4. All output is escaped (`esc_html`, `esc_url`, `esc_attr`); all input is nonce-checked, capability-checked and sanitised.

## Layout and responsiveness
- Desktop (above 1100px): sidebar + 4-column CSS grid (wide = 2 columns, tall = 2 rows, `grid-auto-flow: dense`).
- Tablet (701-1100px): sidebar becomes an off-canvas drawer, 2-column grid.
- Mobile (700px and below): single column, scrollable tabs, simplified top bar.

## Theme overrides
Copy any file from `templates/` to `your-theme/buymore-dashboard/` to override it.

## Card images (v1.1)
- All bundled demo artwork lives in `assets/img/demo/` and is **800px wide**. It is used automatically until a card gets a Featured Image.
- New uploads are also generated at 800px wide (`bmd_card` image size). Upload images at least 800px wide for sharp results; older uploads can be regenerated with the *Regenerate Thumbnails* plugin.
- **Image style** (Card details box):
  - *Auto / Designed artwork*: the image fills the card edge to edge, centred, and already contains its text/icons (live ones are hidden).
  - *Plain photo*: the image is a normal photo and the live title, button, price and icons are shown on top.

## Duplicate demo cards (fixed in v1.2)
Deleting and re-installing the plugin used to add a second set of demo cards, because cards are kept on uninstall. Now demo cards are only created on a site with no cards, and on update any exact duplicates of the bundled demo cards are moved to the Trash (recoverable under BuyMore > All Cards > Trash).

## Notes
- Cards with no image and no matching demo artwork fall back to simple SVG placeholders.
- The Inter font is loaded from Google Fonts; a system font stack is the fallback.
- The "Filters" button is visual only, matching the reference.
