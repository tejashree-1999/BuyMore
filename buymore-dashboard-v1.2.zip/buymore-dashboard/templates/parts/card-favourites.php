<?php
/**
 * Favourites slider card. Var: $card
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<article class="<?php echo esc_attr( BMD_Renderer::classes( $card ) ); ?>"
	data-title="<?php echo esc_attr( strtolower( $card['title'] ) ); ?>">
	<div class="bmd-fav__head">
		<span class="bmd-fav__title"><?php echo esc_html( $card['title'] ); ?></span>
		<span class="bmd-fav__nav">
			<button type="button" data-bmd-slide="-1" aria-label="<?php esc_attr_e( 'Previous', 'buymore-dashboard' ); ?>"><?php echo BMD_Icons::get( 'left', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
			<button type="button" data-bmd-slide="1" aria-label="<?php esc_attr_e( 'Next', 'buymore-dashboard' ); ?>"><?php echo BMD_Icons::get( 'right', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
		</span>
	</div>
	<div class="bmd-fav__track" tabindex="0">
		<?php foreach ( $card['gallery'] as $i => $url ) : ?>
			<div class="bmd-fav__slide bmd-fav__slide--<?php echo (int) ( $i % 2 ); ?>">
				<img src="<?php echo esc_url( $url ); ?>" alt="" loading="lazy">
			</div>
		<?php endforeach; ?>
	</div>
	<?php if ( $card['button_text'] ) : ?>
		<a class="bmd-pill bmd-pill--white bmd-fav__all" href="<?php echo esc_url( $card['button_url'] ); ?>"><?php echo esc_html( $card['button_text'] ); ?></a>
	<?php endif; ?>
</article>
