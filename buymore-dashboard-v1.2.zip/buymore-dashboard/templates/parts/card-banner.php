<?php
/**
 * Banner / promo / CTA card. Var: $card
 *
 * Designed mode (default when an image is set):
 *  - banner / promo: the image fills the card and already contains the text,
 *    so the live text is kept for screen readers only.
 *  - cta: image sits on the right, live text and arrow on top.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$designed  = ! empty( $card['designed'] );
$text_baked = $designed && in_array( $card['type'], array( 'banner', 'promo' ), true );
$show_arrow = 'banner' !== $card['type'];
$style      = $card['bg'] ? 'background-color:' . $card['bg'] . ';' : '';
?>
<article class="<?php echo esc_attr( BMD_Renderer::classes( $card ) ); ?>"
	style="<?php echo esc_attr( $style ); ?>"
	data-title="<?php echo esc_attr( strtolower( $card['title'] ) ); ?>">
	<div class="bmd-card__media"><img src="<?php echo esc_url( $card['image'] ); ?>" alt="<?php echo $text_baked ? esc_attr( $card['title'] ) : ''; ?>" loading="lazy"></div>
	<div class="bmd-card__body<?php echo $text_baked ? ' bmd-sr' : ''; ?>">
		<h3 class="bmd-card__title"><?php echo esc_html( $card['title'] ); ?></h3>
		<?php if ( $card['subtitle'] ) : ?>
			<p class="bmd-card__sub"><?php echo esc_html( $card['subtitle'] ); ?></p>
		<?php endif; ?>
		<?php if ( 'banner' === $card['type'] && $card['button_text'] && ! $text_baked ) : ?>
			<a class="bmd-pill bmd-pill--white" href="<?php echo esc_url( $card['button_url'] ); ?>"><?php echo esc_html( $card['button_text'] ); ?></a>
		<?php endif; ?>
	</div>
	<?php if ( $text_baked && 'banner' === $card['type'] ) : ?>
		<a class="bmd-card__cover" href="<?php echo esc_url( $card['button_url'] ); ?>" aria-label="<?php echo esc_attr( $card['button_text'] ? $card['button_text'] : $card['title'] ); ?>"></a>
	<?php endif; ?>
	<?php if ( $show_arrow ) : ?>
		<a class="bmd-arrow" href="<?php echo esc_url( $card['button_url'] ); ?>" aria-label="<?php echo esc_attr( $card['title'] ); ?>">
			<?php echo BMD_Icons::get( 'arrow', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</a>
	<?php endif; ?>
</article>
