<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$nav_icons = array( 'spark', 'explore', 'bag', 'gift', 'pin' );
?>
<aside class="bmd-sidebar" id="bmd-sidebar">
	<div class="bmd-sidebar__head">
		<span class="bmd-logo"><?php echo esc_html( BMD_Settings::get( 'logo_text' ) ); ?></span>
		<button type="button" class="bmd-iconbtn bmd-sidebar__close" data-bmd-nav-toggle aria-label="<?php esc_attr_e( 'Close menu', 'buymore-dashboard' ); ?>">
			<?php echo BMD_Icons::get( 'close', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</button>
	</div>

	<nav class="bmd-nav" aria-label="<?php esc_attr_e( 'Dashboard', 'buymore-dashboard' ); ?>">
		<?php foreach ( BMD_Settings::lines( 'menu_items' ) as $i => $item ) : ?>
			<a class="bmd-nav__link<?php echo $item['active'] ? ' is-active' : ''; ?>" href="<?php echo esc_url( $item['url'] ); ?>">
				<?php echo BMD_Icons::get( isset( $nav_icons[ $i ] ) ? $nav_icons[ $i ] : 'pin', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<span><?php echo esc_html( $item['label'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</nav>

	<div class="bmd-side-group">
		<p class="bmd-side-title"><?php esc_html_e( 'Quick actions', 'buymore-dashboard' ); ?></p>
		<?php foreach ( BMD_Settings::lines( 'quick_items' ) as $item ) : ?>
			<a class="bmd-side-link" href="<?php echo esc_url( $item['url'] ); ?>">
				<?php echo BMD_Icons::get( 'plus', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<span><?php echo esc_html( $item['label'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</div>

	<div class="bmd-side-group">
		<p class="bmd-side-title">
			<?php esc_html_e( 'Last orders', 'buymore-dashboard' ); ?>
			<b><?php echo esc_html( BMD_Settings::get( 'orders_count' ) ); ?></b>
		</p>
		<?php foreach ( BMD_Settings::lines( 'last_orders' ) as $item ) : ?>
			<a class="bmd-side-link bmd-side-link--order" href="<?php echo esc_url( $item['url'] ); ?>">
				<i class="bmd-order-thumb"></i>
				<span><?php echo esc_html( $item['label'] ); ?></span>
				<em><?php esc_html_e( 'view order', 'buymore-dashboard' ); ?></em>
			</a>
		<?php endforeach; ?>
		<a class="bmd-side-more" href="#"><?php esc_html_e( 'See all', 'buymore-dashboard' ); ?></a>
	</div>

	<a class="bmd-logout" href="<?php echo esc_url( BMD_Settings::get( 'logout_url' ) ); ?>">
		<?php echo BMD_Icons::get( 'logout', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<span><?php echo esc_html( BMD_Settings::get( 'logout_label' ) ); ?></span>
	</a>
</aside>
