<?php
/**
 * Image card. Var: $card
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$style = $card['bg'] ? 'background-color:' . $card['bg'] . ';' : '';
?>
<article class="<?php echo esc_attr( BMD_Renderer::classes( $card ) ); ?>"
	style="<?php echo esc_attr( $style ); ?>"
	data-title="<?php echo esc_attr( strtolower( $card['title'] ) ); ?>">
	<div class="bmd-card__media"><img src="<?php echo esc_url( $card['image'] ); ?>" alt="<?php echo esc_attr( $card['title'] ); ?>" loading="lazy"></div>
	<button type="button" class="bmd-heart bmd-heart--corner" aria-pressed="false" aria-label="<?php esc_attr_e( 'Add to wishlist', 'buymore-dashboard' ); ?>">
		<?php echo BMD_Icons::get( 'heart', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	</button>
	<?php if ( $card['button_text'] ) : ?>
		<a class="bmd-pill bmd-pill--glass" href="<?php echo esc_url( $card['button_url'] ); ?>"><?php echo esc_html( $card['button_text'] ); ?></a>
	<?php endif; ?>
</article>
