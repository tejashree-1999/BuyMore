<?php
/**
 * Product card. Var: $card
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<article class="<?php echo esc_attr( BMD_Renderer::classes( $card ) ); ?>"
	data-title="<?php echo esc_attr( strtolower( $card['title'] ) ); ?>">
	<?php if ( empty( $card['designed'] ) ) : ?>
	<div class="bmd-product__top">
		<span class="bmd-dots">
			<?php foreach ( $card['colors'] as $hex ) : ?>
				<i style="background-color:<?php echo esc_attr( $hex ); ?>"></i>
			<?php endforeach; ?>
		</span>
		<button type="button" class="bmd-heart" aria-pressed="false" aria-label="<?php esc_attr_e( 'Add to wishlist', 'buymore-dashboard' ); ?>">
			<?php echo BMD_Icons::get( 'heart', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</button>
	</div>
	<?php endif; ?>
	<div class="bmd-card__media"><img src="<?php echo esc_url( $card['image'] ); ?>" alt="<?php echo esc_attr( $card['title'] ); ?>" loading="lazy"></div>
	<div class="bmd-product__foot">
		<div>
			<?php if ( $card['label'] ) : ?>
				<span class="bmd-label"><?php echo esc_html( $card['label'] ); ?></span>
			<?php endif; ?>
			<h3 class="bmd-product__name"><?php echo esc_html( $card['title'] ); ?></h3>
		</div>
		<?php if ( $card['price'] ) : ?>
			<a class="bmd-price" href="<?php echo esc_url( $card['button_url'] ); ?>"><?php echo esc_html( $card['price'] ); ?></a>
		<?php endif; ?>
	</div>
</article>
