<?php
/**
 * Main dashboard layout.
 * Vars: $limit (int), $fullwidth (bool)
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$avatar = BMD_Settings::get( 'avatar_url' );
$name   = BMD_Settings::get( 'user_name' );
?>
<div class="bmd-stage<?php echo $fullwidth ? ' bmd-stage--full' : ''; ?>">
	<div class="bmd-app" data-bmd-app>

		<?php BMD_Renderer::template( 'parts/sidebar' ); ?>
		<div class="bmd-overlay" data-bmd-nav-toggle></div>

		<div class="bmd-main">

			<header class="bmd-topbar">
				<button type="button" class="bmd-iconbtn bmd-burger" data-bmd-nav-toggle aria-label="<?php esc_attr_e( 'Toggle menu', 'buymore-dashboard' ); ?>">
					<?php echo BMD_Icons::get( 'menu', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</button>

				<div class="bmd-stat">
					<strong><?php echo esc_html( BMD_Settings::get( 'orders_count' ) ); ?></strong>
					<span><?php echo esc_html( BMD_Settings::get( 'orders_label' ) ); ?><small><?php echo esc_html( BMD_Settings::get( 'orders_sub' ) ); ?></small></span>
				</div>

				<div class="bmd-switch" role="tablist">
					<button type="button" class="is-active" role="tab" aria-selected="true"><?php esc_html_e( 'Dashboard', 'buymore-dashboard' ); ?></button>
					<button type="button" role="tab" aria-selected="false"><?php esc_html_e( 'Website', 'buymore-dashboard' ); ?></button>
				</div>

				<div class="bmd-userbar">
					<button type="button" class="bmd-cart">
						<?php echo BMD_Icons::get( 'cart', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<span><?php echo esc_html( BMD_Settings::get( 'cart_label' ) ); ?></span>
					</button>
					<span class="bmd-avatars" aria-hidden="true"><i></i><i></i><b><?php echo esc_html( BMD_Settings::get( 'cart_count' ) ); ?></b></span>
					<span class="bmd-user">
						<?php if ( $avatar ) : ?>
							<img src="<?php echo esc_url( $avatar ); ?>" alt="">
						<?php else : ?>
							<span class="bmd-user__initial"><?php echo esc_html( strtoupper( substr( $name, 0, 1 ) ) ); ?></span>
						<?php endif; ?>
						<span class="bmd-user__name"><?php echo esc_html( $name ); ?></span>
					</span>
				</div>
			</header>

			<div class="bmd-subhead">
				<h2 class="bmd-subhead__title"><?php echo esc_html( BMD_Settings::get( 'page_title' ) ); ?></h2>

				<div class="bmd-tabs" role="tablist" data-bmd-tabs>
					<?php foreach ( BMD_Renderer::tabs() as $i => $tab ) : ?>
						<button type="button" role="tab" class="bmd-tab<?php echo 0 === $i ? ' is-active' : ''; ?>" data-gender="<?php echo esc_attr( $tab['slug'] ); ?>" aria-selected="<?php echo 0 === $i ? 'true' : 'false'; ?>">
							<?php echo BMD_Icons::get( in_array( $tab['slug'], array( 'men', 'women' ), true ) ? $tab['slug'] : 'all', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<span><?php echo esc_html( $tab['name'] ); ?></span>
						</button>
					<?php endforeach; ?>
				</div>

				<div class="bmd-tools">
					<input type="search" class="bmd-search" data-bmd-search placeholder="<?php esc_attr_e( 'Search cards', 'buymore-dashboard' ); ?>" aria-label="<?php esc_attr_e( 'Search cards', 'buymore-dashboard' ); ?>">
					<button type="button" class="bmd-filters"><?php esc_html_e( 'Filters', 'buymore-dashboard' ); ?><i class="bmd-dot"></i></button>
					<button type="button" class="bmd-iconbtn bmd-iconbtn--ring" data-bmd-search-toggle aria-label="<?php esc_attr_e( 'Search', 'buymore-dashboard' ); ?>">
						<?php echo BMD_Icons::get( 'search', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</button>
				</div>
			</div>

			<div class="bmd-grid" data-bmd-grid aria-live="polite">
				<?php echo BMD_Renderer::cards_html( 'all', $limit ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>

		</div>
	</div>
</div>
