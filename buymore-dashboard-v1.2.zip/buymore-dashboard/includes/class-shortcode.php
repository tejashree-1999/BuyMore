<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * [buymore_dashboard] shortcode and front-end asset loading.
 * Attributes: limit="20" fullwidth="yes|no"
 */
class BMD_Shortcode {

	public function __construct() {
		add_shortcode( 'buymore_dashboard', array( $this, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue' ) );
	}

	/**
	 * Enqueue assets only on pages that contain the shortcode.
	 */
	public function maybe_enqueue() {
		$post = get_post();
		if ( $post && is_singular() && has_shortcode( $post->post_content, 'buymore_dashboard' ) ) {
			$this->enqueue();
		}
	}

	private function enqueue() {
		wp_enqueue_style( 'bmd-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap', array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters
		wp_enqueue_style( 'bmd-dashboard', BMD_URL . 'assets/css/dashboard.css', array(), BMD_VERSION );
		wp_enqueue_script( 'bmd-dashboard', BMD_URL . 'assets/js/dashboard.js', array(), BMD_VERSION, true );
		wp_localize_script(
			'bmd-dashboard',
			'BMD',
			array( 'restUrl' => esc_url_raw( rest_url( 'buymore/v1/cards' ) ) )
		);
	}

	public function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'limit'     => 20,
				'fullwidth' => 'yes',
			),
			$atts,
			'buymore_dashboard'
		);
		$this->enqueue(); // Fallback for content rendered outside the main loop.

		ob_start();
		BMD_Renderer::template(
			'dashboard',
			array(
				'limit'     => absint( $atts['limit'] ),
				'fullwidth' => 'yes' === $atts['fullwidth'],
			)
		);
		return ob_get_clean();
	}
}
