<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the "Dashboard Card" custom post type, the "Gender" taxonomy
 * (powers the All / Men / Women tabs) and helpful admin list columns.
 */
class BMD_Post_Types {

	const CPT = 'bmd_card';
	const TAX = 'bmd_gender';

	public function __construct() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_filter( 'manage_' . self::CPT . '_posts_columns', array( $this, 'columns' ) );
		add_action( 'manage_' . self::CPT . '_posts_custom_column', array( $this, 'column_content' ), 10, 2 );
	}

	public static function register() {
		register_post_type(
			self::CPT,
			array(
				'labels'        => array(
					'name'               => __( 'Dashboard Cards', 'buymore-dashboard' ),
					'singular_name'      => __( 'Dashboard Card', 'buymore-dashboard' ),
					'add_new_item'       => __( 'Add New Card', 'buymore-dashboard' ),
					'edit_item'          => __( 'Edit Card', 'buymore-dashboard' ),
					'all_items'          => __( 'All Cards', 'buymore-dashboard' ),
					'menu_name'          => __( 'BuyMore', 'buymore-dashboard' ),
					'not_found'          => __( 'No cards yet. Add your first card.', 'buymore-dashboard' ),
					'featured_image'     => __( 'Card image', 'buymore-dashboard' ),
					'set_featured_image' => __( 'Set card image', 'buymore-dashboard' ),
				),
				'public'        => false,
				'show_ui'       => true,
				'show_in_menu'  => true,
				'menu_icon'     => 'dashicons-screenoptions',
				'menu_position' => 25,
				'supports'      => array( 'title', 'thumbnail', 'page-attributes' ),
				'show_in_rest'  => true,
			)
		);

		register_taxonomy(
			self::TAX,
			self::CPT,
			array(
				'labels'            => array(
					'name'          => __( 'Genders', 'buymore-dashboard' ),
					'singular_name' => __( 'Gender', 'buymore-dashboard' ),
				),
				'public'            => false,
				'show_ui'           => true,
				'hierarchical'      => true,
				'show_admin_column' => true,
				'show_in_rest'      => true,
			)
		);
	}

	public function columns( $cols ) {
		return array(
			'cb'                    => $cols['cb'],
			'bmd_thumb'             => __( 'Image', 'buymore-dashboard' ),
			'title'                 => __( 'Title', 'buymore-dashboard' ),
			'bmd_type'              => __( 'Type', 'buymore-dashboard' ),
			'bmd_size'              => __( 'Size', 'buymore-dashboard' ),
			'taxonomy-' . self::TAX => __( 'Gender', 'buymore-dashboard' ),
			'bmd_order'             => __( 'Order', 'buymore-dashboard' ),
		);
	}

	public function column_content( $col, $post_id ) {
		switch ( $col ) {
			case 'bmd_thumb':
				echo has_post_thumbnail( $post_id ) ? get_the_post_thumbnail( $post_id, array( 48, 48 ) ) : '&mdash;'; // phpcs:ignore WordPress.Security.EscapeOutput
				break;
			case 'bmd_type':
				echo esc_html( ucfirst( (string) get_post_meta( $post_id, '_bmd_card_type', true ) ) );
				break;
			case 'bmd_size':
				echo esc_html( ucfirst( (string) get_post_meta( $post_id, '_bmd_size', true ) ) );
				break;
			case 'bmd_order':
				echo (int) get_post_field( 'menu_order', $post_id );
				break;
		}
	}
}
