<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Creates demo cards + gender terms on activation so the page is populated instantly.
 * Runs once; set the "bmd_seeded" option to skip.
 */
class BMD_Seeder {

	public static function seed() {
		foreach ( array( 'Men', 'Women', 'Unisex' ) as $term ) {
			if ( ! term_exists( $term, BMD_Post_Types::TAX ) ) {
				wp_insert_term( $term, BMD_Post_Types::TAX );
			}
		}

		// Never add demo cards on top of existing ones (this caused duplicates
		// when the plugin was deleted and re-installed, because the cards stay).
		$counts = wp_count_posts( BMD_Post_Types::CPT );
		if ( get_option( 'bmd_seeded' ) || ( (int) $counts->publish + (int) $counts->draft + (int) $counts->pending + (int) $counts->private ) > 0 ) {
			return;
		}

		// Order matters: it lets the CSS grid reproduce the reference layout.
		$cards = array(
			array( 'Get up to 50% off', 'banner', 'wide', 'unisex', 1, array( 'button_text' => 'Get Discount', 'bg_color' => '#c9ecd4' ) ),
			array( 'WMX Rubber Zebra sandal', 'product', 'tall', 'women', 2, array( 'label' => 'Our Picks', 'price' => '$36', 'colors' => '#f4a0c8,#f7d84a' ) ),
			array( 'Supper Skinny jogger in brown', 'product', 'tall', 'men', 3, array( 'label' => 'Your Choice', 'price' => '$89', 'colors' => '#f2d94e,#111111' ) ),
			array( "Winter's weekend", 'promo', 'wide', 'unisex', 4, array( 'subtitle' => 'keep it casual', 'bg_color' => '#fde9a3' ) ),
			array( 'Orange knits', 'image', 'small', 'women', 5, array( 'button_text' => 'Avail Offers', 'bg_color' => '#e6e6e6' ) ),
			array( 'Favourites', 'favourites', 'small', 'unisex', 6, array( 'button_text' => 'See All' ) ),
			array( 'Bring Bold Fashion', 'cta', 'wide', 'men', 7, array( 'subtitle' => 'Layers on Layers', 'bg_color' => '#eef3f1' ) ),
		);

		foreach ( $cards as $c ) {
			$meta = array_merge(
				array(
					'_bmd_card_type' => $c[1],
					'_bmd_size'      => $c[2],
				),
				self::prefix( $c[5] )
			);
			$id = wp_insert_post(
				array(
					'post_type'   => BMD_Post_Types::CPT,
					'post_title'  => $c[0],
					'post_status' => 'publish',
					'menu_order'  => $c[4],
					'meta_input'  => $meta,
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				wp_set_object_terms( $id, $c[3], BMD_Post_Types::TAX );
			}
		}

		update_option( 'bmd_seeded', 1 );
	}

	/**
	 * Move exact duplicate DEMO cards to the Trash (recoverable).
	 * Only the bundled demo titles are touched, and only when type and size
	 * match. The copy with a Featured Image (else the oldest) is kept.
	 */
	public static function dedupe() {
		$demo_slugs = array( 'get-up-to-50-off', 'wmx-rubber-zebra-sandal', 'supper-skinny-jogger-in-brown', 'winters-weekend', 'orange-knits', 'favourites', 'bring-bold-fashion' );

		$posts = get_posts(
			array(
				'post_type'      => BMD_Post_Types::CPT,
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => -1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
				'no_found_rows'  => true,
			)
		);

		$groups = array();
		foreach ( $posts as $post ) {
			$slug = sanitize_title( $post->post_title );
			if ( ! in_array( $slug, $demo_slugs, true ) ) {
				continue;
			}
			$key              = $slug . '|' . get_post_meta( $post->ID, '_bmd_card_type', true ) . '|' . get_post_meta( $post->ID, '_bmd_size', true );
			$groups[ $key ][] = $post;
		}

		foreach ( $groups as $group ) {
			if ( count( $group ) < 2 ) {
				continue;
			}
			// Keeper: first one that has a Featured Image, otherwise the oldest.
			$keeper = $group[0];
			foreach ( $group as $p ) {
				if ( has_post_thumbnail( $p->ID ) ) {
					$keeper = $p;
					break;
				}
			}
			foreach ( $group as $p ) {
				if ( $p->ID !== $keeper->ID ) {
					wp_trash_post( $p->ID );
				}
			}
		}
	}

	private static function prefix( array $meta ) {
		$out = array();
		foreach ( $meta as $k => $v ) {
			$out[ '_bmd_' . $k ] = $v;
		}
		return $out;
	}
}
