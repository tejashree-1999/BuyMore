<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Native meta box (no ACF) holding every editable card field.
 */
class BMD_Meta_Boxes {

	const NONCE = 'bmd_card_nonce';

	public function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'add' ) );
		add_action( 'save_post_' . BMD_Post_Types::CPT, array( $this, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	/**
	 * Field definitions: key => label, type, help, options.
	 */
	public static function fields() {
		return array(
			'card_type'   => array(
				'label'   => __( 'Card type', 'buymore-dashboard' ),
				'type'    => 'select',
				'options' => array(
					'banner'     => __( 'Banner (title + button)', 'buymore-dashboard' ),
					'promo'      => __( 'Promo (title + subtitle + arrow)', 'buymore-dashboard' ),
					'product'    => __( 'Product (image, label, price)', 'buymore-dashboard' ),
					'image'      => __( 'Image card (photo + button)', 'buymore-dashboard' ),
					'favourites' => __( 'Favourites slider', 'buymore-dashboard' ),
					'cta'        => __( 'Call to action (title + subtitle + arrow)', 'buymore-dashboard' ),
				),
			),
			'size'        => array(
				'label'   => __( 'Grid size', 'buymore-dashboard' ),
				'type'    => 'select',
				'options' => array(
					'small' => __( 'Small (1 column)', 'buymore-dashboard' ),
					'wide'  => __( 'Wide (2 columns)', 'buymore-dashboard' ),
					'tall'  => __( 'Tall (2 rows)', 'buymore-dashboard' ),
				),
			),
			'image_mode'  => array(
				'label'   => __( 'Image style', 'buymore-dashboard' ),
				'type'    => 'select',
				'options' => array(
					''         => __( 'Auto (designed artwork when an image is set)', 'buymore-dashboard' ),
					'designed' => __( 'Designed artwork: image fills the card and already contains the text/icons', 'buymore-dashboard' ),
					'plain'    => __( 'Plain photo: show the live title, button and icons on top', 'buymore-dashboard' ),
				),
			),
			'subtitle'    => array( 'label' => __( 'Subtitle', 'buymore-dashboard' ), 'type' => 'text' ),
			'button_text' => array( 'label' => __( 'Button text', 'buymore-dashboard' ), 'type' => 'text' ),
			'button_url'  => array( 'label' => __( 'Link URL', 'buymore-dashboard' ), 'type' => 'url' ),
			'label'       => array( 'label' => __( 'Product label (e.g. Our Picks)', 'buymore-dashboard' ), 'type' => 'text' ),
			'price'       => array( 'label' => __( 'Price (e.g. $36)', 'buymore-dashboard' ), 'type' => 'text' ),
			'colors'      => array(
				'label' => __( 'Colour dots (comma separated hex)', 'buymore-dashboard' ),
				'type'  => 'text',
				'help'  => __( 'Example: #f4a0c8, #f7d84a', 'buymore-dashboard' ),
			),
			'bg_color'    => array( 'label' => __( 'Background colour', 'buymore-dashboard' ), 'type' => 'color' ),
			'gallery'     => array(
				'label' => __( 'Slider images (favourites card)', 'buymore-dashboard' ),
				'type'  => 'gallery',
			),
		);
	}

	public function add() {
		add_meta_box(
			'bmd_card_details',
			__( 'Card details', 'buymore-dashboard' ),
			array( $this, 'render' ),
			BMD_Post_Types::CPT,
			'normal',
			'high'
		);
	}

	public function assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || BMD_Post_Types::CPT !== $screen->post_type || ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script( 'bmd-admin', BMD_URL . 'assets/js/admin.js', array( 'jquery' ), BMD_VERSION, true );
	}

	public function render( $post ) {
		wp_nonce_field( 'bmd_save_card', self::NONCE );
		echo '<table class="form-table" role="presentation">';
		foreach ( self::fields() as $key => $f ) {
			$value = get_post_meta( $post->ID, '_bmd_' . $key, true );
			$id    = 'bmd_' . $key;
			echo '<tr><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( $f['label'] ) . '</label></th><td>';
			switch ( $f['type'] ) {
				case 'select':
					echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '">';
					foreach ( $f['options'] as $val => $text ) {
						printf( '<option value="%s"%s>%s</option>', esc_attr( $val ), selected( $value, $val, false ), esc_html( $text ) );
					}
					echo '</select>';
					break;
				case 'color':
					printf( '<input type="color" id="%1$s" name="%1$s" value="%2$s">', esc_attr( $id ), esc_attr( $value ? $value : '#ffffff' ) );
					printf( ' <label><input type="checkbox" name="bmd_bg_color_clear" value="1"%s> %s</label>', checked( ! $value, true, false ), esc_html__( 'No background colour', 'buymore-dashboard' ) );
					break;
				case 'gallery':
					$ids = array_filter( array_map( 'absint', explode( ',', (string) $value ) ) );
					printf( '<input type="hidden" id="%1$s" name="%1$s" value="%2$s">', esc_attr( $id ), esc_attr( implode( ',', $ids ) ) );
					echo '<button type="button" class="button" id="bmd-gallery-btn">' . esc_html__( 'Select images', 'buymore-dashboard' ) . '</button>';
					echo '<div id="bmd-gallery-preview" style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">';
					foreach ( $ids as $img_id ) {
						echo wp_get_attachment_image( $img_id, array( 60, 60 ) ); // phpcs:ignore WordPress.Security.EscapeOutput
					}
					echo '</div>';
					break;
				default:
					printf(
						'<input type="%1$s" class="regular-text" id="%2$s" name="%2$s" value="%3$s">',
						'url' === $f['type'] ? 'url' : 'text',
						esc_attr( $id ),
						esc_attr( $value )
					);
			}
			if ( ! empty( $f['help'] ) ) {
				echo '<p class="description">' . esc_html( $f['help'] ) . '</p>';
			}
			echo '</td></tr>';
		}
		echo '</table>';
		echo '<p class="description">' . esc_html__( 'Tip: set the Featured Image for the card photo, use Order (Page Attributes) to position the card, and tick a Gender to control the filter tabs.', 'buymore-dashboard' ) . '</p>';
	}

	public function save( $post_id, $post ) {
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE ] ) ), 'bmd_save_card' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( self::fields() as $key => $f ) {
			$name = 'bmd_' . $key;
			$raw  = isset( $_POST[ $name ] ) ? wp_unslash( $_POST[ $name ] ) : ''; // phpcs:ignore WordPress.Security

			switch ( $f['type'] ) {
				case 'select':
					$val = array_key_exists( $raw, $f['options'] ) ? $raw : key( $f['options'] );
					break;
				case 'url':
					$val = esc_url_raw( $raw );
					break;
				case 'color':
					$val = ! empty( $_POST['bmd_bg_color_clear'] ) ? '' : (string) sanitize_hex_color( $raw );
					break;
				case 'gallery':
					$val = implode( ',', array_filter( array_map( 'absint', explode( ',', $raw ) ) ) );
					break;
				default:
					$val = 'colors' === $key ? self::sanitize_colors( $raw ) : sanitize_text_field( $raw );
			}
			update_post_meta( $post_id, '_bmd_' . $key, $val );
		}
	}

	/**
	 * Keep only valid hex colours from a comma list.
	 */
	public static function sanitize_colors( $raw ) {
		$out = array();
		foreach ( explode( ',', (string) $raw ) as $c ) {
			$hex = sanitize_hex_color( trim( $c ) );
			if ( $hex ) {
				$out[] = $hex;
			}
		}
		return implode( ',', $out );
	}
}
