<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Public REST endpoint used by the All / Men / Women tabs:
 *   GET /wp-json/buymore/v1/cards?gender=men
 */
class BMD_Rest {

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
	}

	public function routes() {
		register_rest_route(
			'buymore/v1',
			'/cards',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_cards' ),
				'permission_callback' => '__return_true', // Read-only public content.
				'args'                => array(
					'gender' => array(
						'type'              => 'string',
						'default'           => 'all',
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);
	}

	public function get_cards( WP_REST_Request $request ) {
		return rest_ensure_response(
			array(
				'html' => BMD_Renderer::cards_html( $request->get_param( 'gender' ) ),
			)
		);
	}
}
