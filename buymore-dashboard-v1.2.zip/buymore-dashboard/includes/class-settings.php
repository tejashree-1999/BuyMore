<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings page (BuyMore > Dashboard Settings) built with the Settings API.
 * Controls the top bar, sidebar menus and user block.
 */
class BMD_Settings {

	const OPTION = 'bmd_settings';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'register' ) );
	}

	public static function defaults() {
		return array(
			'logo_text'    => 'BuyMore',
			'orders_count' => '37',
			'orders_label' => 'Orders',
			'orders_sub'   => 'Last 7 days',
			'cart_label'   => 'Cart',
			'cart_count'   => '+8',
			'user_name'    => 'Ryana',
			'avatar_url'   => '',
			'page_title'   => 'Explore',
			'menu_items'   => "Popular Products|#\nExplore New|#|active\nClothing and Shoes|#\nGifts and Living|#\nInspiration|#",
			'quick_items'  => "Request for product|#\nAdd member|#",
			'last_orders'  => "DXC Nike...|#\nOuterwear...|#",
			'logout_label' => 'Log out',
			'logout_url'   => '#',
		);
	}

	/**
	 * Get one setting (falls back to default).
	 */
	public static function get( $key ) {
		$saved    = get_option( self::OPTION, array() );
		$defaults = self::defaults();
		if ( isset( $saved[ $key ] ) && '' !== $saved[ $key ] ) {
			return $saved[ $key ];
		}
		return isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	}

	/**
	 * Parse "Label|URL|active" textarea lines into arrays.
	 */
	public static function lines( $key ) {
		$items = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) self::get( $key ) ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$parts   = array_map( 'trim', explode( '|', $line ) );
			$items[] = array(
				'label'  => $parts[0],
				'url'    => isset( $parts[1] ) && '' !== $parts[1] ? $parts[1] : '#',
				'active' => isset( $parts[2] ) && 'active' === $parts[2],
			);
		}
		return $items;
	}

	public function menu() {
		add_submenu_page(
			'edit.php?post_type=' . BMD_Post_Types::CPT,
			__( 'Dashboard Settings', 'buymore-dashboard' ),
			__( 'Dashboard Settings', 'buymore-dashboard' ),
			'manage_options',
			'bmd-settings',
			array( $this, 'page' )
		);
	}

	public function register() {
		register_setting(
			'bmd_settings_group',
			self::OPTION,
			array( 'sanitize_callback' => array( $this, 'sanitize' ) )
		);
	}

	public function sanitize( $input ) {
		$input = (array) $input;
		$clean = array();
		foreach ( array_keys( self::defaults() ) as $key ) {
			$val = isset( $input[ $key ] ) ? wp_unslash( $input[ $key ] ) : '';
			if ( in_array( $key, array( 'menu_items', 'quick_items', 'last_orders' ), true ) ) {
				$clean[ $key ] = sanitize_textarea_field( $val );
			} elseif ( in_array( $key, array( 'avatar_url', 'logout_url' ), true ) ) {
				$clean[ $key ] = esc_url_raw( $val );
			} else {
				$clean[ $key ] = sanitize_text_field( $val );
			}
		}
		return $clean;
	}

	private function text( $key, $label ) {
		printf(
			'<tr><th scope="row"><label for="bmd_%1$s">%2$s</label></th><td><input type="text" class="regular-text" id="bmd_%1$s" name="%3$s[%1$s]" value="%4$s"></td></tr>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( self::OPTION ),
			esc_attr( self::get( $key ) )
		);
	}

	private function area( $key, $label, $help ) {
		printf(
			'<tr><th scope="row"><label for="bmd_%1$s">%2$s</label></th><td><textarea class="large-text code" rows="6" id="bmd_%1$s" name="%3$s[%1$s]">%4$s</textarea><p class="description">%5$s</p></td></tr>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( self::OPTION ),
			esc_textarea( self::get( $key ) ),
			esc_html( $help )
		);
	}

	public function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$help = __( 'One item per line: Label|URL. Add |active as a third value to highlight an item.', 'buymore-dashboard' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'BuyMore Dashboard Settings', 'buymore-dashboard' ); ?></h1>
			<p><?php esc_html_e( 'Place the dashboard on any page with the shortcode:', 'buymore-dashboard' ); ?> <code>[buymore_dashboard]</code></p>
			<form method="post" action="options.php">
				<?php settings_fields( 'bmd_settings_group' ); ?>
				<table class="form-table" role="presentation">
					<?php
					$this->text( 'logo_text', __( 'Logo text', 'buymore-dashboard' ) );
					$this->text( 'orders_count', __( 'Orders number', 'buymore-dashboard' ) );
					$this->text( 'orders_label', __( 'Orders label', 'buymore-dashboard' ) );
					$this->text( 'orders_sub', __( 'Orders sub-label', 'buymore-dashboard' ) );
					$this->text( 'cart_label', __( 'Cart label', 'buymore-dashboard' ) );
					$this->text( 'cart_count', __( 'Cart avatars counter', 'buymore-dashboard' ) );
					$this->text( 'user_name', __( 'User name', 'buymore-dashboard' ) );
					$this->text( 'avatar_url', __( 'User avatar URL', 'buymore-dashboard' ) );
					$this->text( 'page_title', __( 'Section title', 'buymore-dashboard' ) );
					$this->area( 'menu_items', __( 'Sidebar menu', 'buymore-dashboard' ), $help );
					$this->area( 'quick_items', __( 'Quick actions', 'buymore-dashboard' ), $help );
					$this->area( 'last_orders', __( 'Last orders', 'buymore-dashboard' ), $help );
					$this->text( 'logout_label', __( 'Log out label', 'buymore-dashboard' ) );
					$this->text( 'logout_url', __( 'Log out URL', 'buymore-dashboard' ) );
					?>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
