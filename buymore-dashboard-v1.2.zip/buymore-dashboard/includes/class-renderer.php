<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Queries cards and renders them through template parts.
 * Themes can override any template by copying it to:
 *   your-theme/buymore-dashboard/{template}.php
 */
class BMD_Renderer {

	/**
	 * Load a template (theme override aware) with variables.
	 */
	public static function template( $name, array $args = array() ) {
		$file = locate_template( 'buymore-dashboard/' . $name . '.php' );
		if ( ! $file ) {
			$file = BMD_PATH . 'templates/' . $name . '.php';
		}
		if ( ! file_exists( $file ) ) {
			return;
		}
		extract( $args, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract
		include $file;
	}

	/**
	 * Gender tabs from the taxonomy (unisex is implicit, shown everywhere).
	 */
	public static function tabs() {
		$terms = get_terms(
			array(
				'taxonomy'   => BMD_Post_Types::TAX,
				'hide_empty' => false,
				'exclude'    => array(),
			)
		);
		$tabs = array( array( 'slug' => 'all', 'name' => __( 'All', 'buymore-dashboard' ) ) );
		if ( is_wp_error( $terms ) ) {
			return $tabs;
		}
		foreach ( $terms as $t ) {
			if ( 'unisex' === $t->slug ) {
				continue;
			}
			$tabs[] = array( 'slug' => $t->slug, 'name' => $t->name );
		}
		return $tabs;
	}

	/**
	 * Bundled demo artwork (800px wide), matched by sanitised card title.
	 * Used only when a card has no Featured Image; uploading one overrides it.
	 */
	private static function demo_image( $title ) {
		$map = array(
			'get-up-to-50-off'              => 'banner-50-off.webp',
			'winters-weekend'               => 'promo-winters-weekend.webp',
			'wmx-rubber-zebra-sandal'       => 'product-wmx-rubber.webp',
			'supper-skinny-jogger-in-brown' => 'product-skinny-jogger.webp',
			'orange-knits'                  => 'image-shop-offers.webp',
			'favourites'                    => 'favourites.webp',
			'bring-bold-fashion'            => 'cta-bold-fashion.webp',
		);
		$slug = sanitize_title( $title );
		return isset( $map[ $slug ] ) ? BMD_URL . 'assets/img/demo/' . $map[ $slug ] : '';
	}

	/**
	 * Normalised data array for one card post.
	 */
	public static function card_data( $post_id ) {
		$type  = get_post_meta( $post_id, '_bmd_card_type', true ) ? get_post_meta( $post_id, '_bmd_card_type', true ) : 'banner';
		$size  = get_post_meta( $post_id, '_bmd_size', true ) ? get_post_meta( $post_id, '_bmd_size', true ) : 'small';
		$title = get_the_title( $post_id );
		$image = get_the_post_thumbnail_url( $post_id, 'bmd_card' );
		$demo  = '';
		if ( ! $image ) {
			$demo  = self::demo_image( $title );
			$image = $demo ? $demo : BMD_URL . 'assets/img/' . ( 'product' === $type ? 'placeholder-product.svg' : 'placeholder-person.svg' );
		}

		// "Designed" = the image is finished artwork that fills the card.
		$mode     = (string) get_post_meta( $post_id, '_bmd_image_mode', true );
		$designed = ( 'designed' === $mode ) || ( '' === $mode && ( $demo || has_post_thumbnail( $post_id ) ) );

		$gallery = array();
		foreach ( array_filter( array_map( 'absint', explode( ',', (string) get_post_meta( $post_id, '_bmd_gallery', true ) ) ) ) as $att_id ) {
			$url = wp_get_attachment_image_url( $att_id, 'bmd_card' );
			if ( $url ) {
				$gallery[] = $url;
			}
		}
		if ( ! $gallery && $demo ) {
			$gallery = array( $demo );
		}
		if ( ! $gallery ) {
			$gallery = array(
				BMD_URL . 'assets/img/placeholder-person.svg',
				BMD_URL . 'assets/img/placeholder-person-2.svg',
				BMD_URL . 'assets/img/placeholder-person.svg',
				BMD_URL . 'assets/img/placeholder-person-2.svg',
			);
		}

		$genders = wp_get_post_terms( $post_id, BMD_Post_Types::TAX, array( 'fields' => 'slugs' ) );

		return array(
			'id'          => $post_id,
			'title'       => $title,
			'designed'    => $designed,
			'type'        => $type,
			'size'        => $size,
			'subtitle'    => (string) get_post_meta( $post_id, '_bmd_subtitle', true ),
			'button_text' => (string) get_post_meta( $post_id, '_bmd_button_text', true ),
			'button_url'  => get_post_meta( $post_id, '_bmd_button_url', true ) ? get_post_meta( $post_id, '_bmd_button_url', true ) : '#',
			'label'       => (string) get_post_meta( $post_id, '_bmd_label', true ),
			'price'       => (string) get_post_meta( $post_id, '_bmd_price', true ),
			'colors'      => array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $post_id, '_bmd_colors', true ) ) ) ),
			'bg'          => (string) get_post_meta( $post_id, '_bmd_bg_color', true ),
			'image'       => $image,
			'gallery'     => $gallery,
			'genders'     => is_wp_error( $genders ) ? array() : $genders,
		);
	}

	/**
	 * Return the HTML of all cards for a gender filter.
	 */
	public static function cards_html( $gender = 'all', $limit = 20 ) {
		$args = array(
			'post_type'      => BMD_Post_Types::CPT,
			'post_status'    => 'publish',
			'posts_per_page' => (int) $limit,
			'orderby'        => array( 'menu_order' => 'ASC', 'date' => 'ASC' ),
			'no_found_rows'  => true,
		);

		$gender = sanitize_key( $gender );
		if ( $gender && 'all' !== $gender ) {
			$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array(
					'taxonomy' => BMD_Post_Types::TAX,
					'field'    => 'slug',
					'terms'    => array( $gender, 'unisex' ),
				),
			);
		}

		$query = new WP_Query( $args );
		ob_start();
		if ( $query->have_posts() ) {
			foreach ( $query->posts as $post ) {
				$card = self::card_data( $post->ID );
				$part = in_array( $card['type'], array( 'banner', 'promo', 'cta' ), true ) ? 'banner' : $card['type'];
				self::template( 'parts/card-' . $part, array( 'card' => $card ) );
			}
		} else {
			echo '<p class="bmd-empty">' . esc_html__( 'No cards found. Add cards under BuyMore > Add New Card.', 'buymore-dashboard' ) . '</p>';
		}
		wp_reset_postdata();
		return ob_get_clean();
	}

	/**
	 * Shared CSS classes for a card wrapper.
	 */
	public static function classes( array $card ) {
		$classes = 'bmd-card bmd-card--' . sanitize_html_class( $card['type'] ) . ' bmd-card--' . sanitize_html_class( $card['size'] );
		if ( ! empty( $card['designed'] ) ) {
			$classes .= ' bmd-card--designed';
		}
		return $classes;
	}
}
