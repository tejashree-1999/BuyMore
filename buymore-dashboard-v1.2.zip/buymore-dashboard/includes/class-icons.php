<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Inline SVG icon set (hard-coded markup, safe to echo).
 */
class BMD_Icons {

	private static $paths = array(
		'spark'   => '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z"/>',
		'explore' => '<circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/>',
		'bag'     => '<path d="M6 7h12l1 13H5L6 7z"/><path d="M9 7a3 3 0 0 1 6 0"/>',
		'gift'    => '<rect x="4" y="9" width="16" height="11" rx="1"/><path d="M12 9v11M3 9h18M12 9c-2-4-6-3-5 0M12 9c2-4 6-3 5 0"/>',
		'pin'     => '<path d="M12 21s-7-6.2-7-11a7 7 0 1 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
		'plus'    => '<path d="M12 5v14M5 12h14"/>',
		'logout'  => '<path d="m10 17-5-5 5-5M5 12h12M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4"/>',
		'heart'   => '<path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/>',
		'search'  => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
		'cart'    => '<path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
		'arrow'   => '<path d="M7 17 17 7M8 7h9v9"/>',
		'left'    => '<path d="m15 6-6 6 6 6"/>',
		'right'   => '<path d="m9 6 6 6-6 6"/>',
		'filter'  => '<path d="M4 6h16M7 12h10M10 18h4"/>',
		'menu'    => '<path d="M4 6h16M4 12h16M4 18h16"/>',
		'close'   => '<path d="m6 6 12 12M18 6 6 18"/>',
		'all'     => '<path d="M9 9h10v10H9z"/><path d="M5 15V5h10"/>',
		'men'     => '<circle cx="12" cy="8" r="3.5"/><path d="M6 20v-3a6 6 0 0 1 12 0v3"/>',
		'women'   => '<circle cx="12" cy="8" r="3.5"/><path d="M12 12v8M9 17h6"/>',
	);

	/**
	 * Return an inline SVG string.
	 */
	public static function get( $name, $size = 16 ) {
		$inner = isset( self::$paths[ $name ] ) ? self::$paths[ $name ] : self::$paths['pin'];
		return sprintf(
			'<svg class="bmd-icon" width="%1$d" height="%1$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%2$s</svg>',
			(int) $size,
			$inner
		);
	}
}
